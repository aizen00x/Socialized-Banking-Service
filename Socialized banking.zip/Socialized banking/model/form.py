from .basic import *
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
import re

def private_constructor_guard(args, create_key):
    if not (len(args) == 1 and args[0] is create_key):
        raise SyntaxError('This object cannot be created directly')

def sanitize_display_handle(display_handle):
    display_handle = display_handle.strip()
    if len(display_handle) > 40:
        raise BindError('Handle is too long')
    if not re.match('^[0-9A-Za-z_]+$', display_handle):
        raise BindError('Only letters, numbers and underlines!')
    # handle: convert to all lower case case
    display_handle = display_handle.lower()
    return display_handle

@export
class LoginForm(Serializable):
    __slots__ = ('display_handle', 'raw_password', '_ph')
    __create_key = object()

    def __init__(self, *args):
        """Private constructor"""
        private_constructor_guard(args, self.__create_key)

    def serialize(self):
        result = self._partially_serialize(exclude=('raw_password',))
        result['raw_password'] = '<protected>'
        return result

    @classmethod
    def from_post_data(cls, post_data):
        result = cls(cls.__create_key)
        result._private_from_post_data(post_data)
        return result

    def _private_from_post_data(self, post_data):
        self.verify_and_bind({
            'display_handle': str,
            'raw_password': str
        }, post_data)
        self.display_handle = sanitize_display_handle(self.display_handle)
        self._ph = PasswordHasher()

    def compare_password(self, password_hash):
        """Returns False when password comparison fails"""
        try:
            self._ph.verify(password_hash, self.raw_password)
            return True
        except VerifyMismatchError:
            return False

@export
class RegistrationForm(Serializable):
    __slots__ = ('display_handle', 'full_name', 'password_hash')
    ## https://stackoverflow.com/a/46459300
    __create_key = object()

    def _sanitize_handle_and_name(self):
        self.display_handle = sanitize_display_handle(self.display_handle)
        # full name
        self.full_name = self.full_name.strip()
        if len(self.full_name) > 200:
            raise BindError('Full name should be under 200 characters')

    def __init__(self, *args):
        """Private constructor"""
        private_constructor_guard(args, self.__create_key)

    @classmethod
    def from_post_data(cls, post_data):
        result = cls(cls.__create_key)
        result._private_from_post_data(post_data)
        return result

    def _private_from_post_data(self, post_data):
        # handle and name
        try:
            fields = {'display_handle': str, 'full_name': str}
            self.verify_and_bind(fields, post_data)
            self._sanitize_handle_and_name()
        except KeyError as e:
            raise BindError('Missing key', e.args) from e
        # password strength
        raw_password = post_data['raw_password']
        if not isinstance(raw_password, str):
            raise BindError('raw_password', str)
        raw_password = raw_password.strip()
        if len(raw_password) < 8:
            raise BindError('Password must be at least 8 characters long')
        # password hashing
        ph = PasswordHasher()
        self.password_hash = ph.hash(raw_password)

    @classmethod
    def from_trusted_data(cls, post_data):
        result = cls(cls.__create_key)
        result._private_from_trusted_data(post_data)
        return result

    def _private_from_trusted_data(self, post_data):
        self.verify_and_bind({
            'display_handle': str,
            'full_name': str,
            'password_hash': str
        }, post_data)
        # normalize
        self.display_handle = self.display_handle.lower()
