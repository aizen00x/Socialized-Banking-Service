from itertools import chain
import inspect

def export(some_object):
    """Export the decorated object to __all__"""
    ## https://stackoverflow.com/a/35710527
    module = inspect.getmodule(some_object)
    name = some_object.__name__
    if not hasattr(module, '__all__'):
        module.__all__ = []
    module.__all__.append(name)
    return some_object

__all__ = ['export']

@export
class BindError(ValueError): pass

@export
class Serializable(object):
    __slots__ = ()

    def _partially_serialize(self, exclude=()):
        result = {}
        ## https://stackoverflow.com/a/6720815
        public_and_private_slots = chain.from_iterable(
            getattr(cls, '__slots__', ()) for cls in self.__class__.__mro__
        )
        public_slots = filter(
            lambda s: not s.startswith('_') and s not in exclude,
            public_and_private_slots
        )
        for attribute in public_slots:
            value = getattr(self, attribute)
            if isinstance(value, Serializable):
                result[attribute] = value.serialize()
            else:
                result[attribute] = value
        return result

    def serialize(self):
        return self._partially_serialize(exclude=())

    def verify_and_bind(self, name_to_type, kw):
        # Perform type checks
        for name, type_ in name_to_type.items():
            if not isinstance(kw[name], type_):
                raise BindError(name, type_, 'not', type(kw[name]))
        # Bind values to class attributes
        for name in name_to_type:
            setattr(self, name, kw[name])
