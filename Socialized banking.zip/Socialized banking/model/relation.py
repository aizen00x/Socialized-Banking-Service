from .basic import *
import datetime

@export
class User(Serializable):
    __slots__ = ('id', 'display_handle', 'full_name')

    def __init__(self, **kwargs):
        if 'full_name' in kwargs and kwargs['full_name'] is None:
            kwargs['full_name'] = ''
        self.verify_and_bind({
            'id': int,
            'display_handle': str,
            'full_name': str
        }, kwargs)

@export
class UserWithCredential(User):
    __slots__ = ('password',)

    def __init__(self, **kwargs):
        self.verify_and_bind({'password': str}, kwargs)
        super().__init__(**kwargs)

@export
class PersonalLedgerEntry(Serializable):
    __slots__ = ('id', 'user', 'other',
                 'your_diff', 'time', 'remaining_balance')

    def __init__(self, **kwargs):
        self.verify_and_bind({
            'id': int,
            'user': int,
            'other': (int, type(None)),
            'your_diff': (int, type(None)),
            'time': (datetime.datetime, datetime.date, type(None)),
            'remaining_balance': (int, type(None))
        }, kwargs)
        # Rewrite the ID object
        type_str = kwargs.get('type')
        if not isinstance(type_str, str):
            raise BindError('type', str)
        self.id = type_str + str(self.id)

    def serialize(self):
        result = super()._partially_serialize(exclude=('time',))
        if self.time is None:
            result['time'] = None
        else:
            result['time'] = self.time.isoformat()
        return result

    def transaction_type(self):
        return self.id[:2]
