## Installation

```bash
# Create a virtual environment
mkdir venvDBProject && cd venvDBProject
python3 -m venv "./"
# Activate the virtual environment
source bin/activate
# Clone the repo or extract ZIP file
git clone https://.../DBProject.git
cd DBProject
# Install dependencies in the venv
python3 -m pip install --upgrade pip setuptools wheel
python3 -m pip install -r requirements.txt
```

## Put database password in the config file

``` bash
cd venvDBProject/DBProject
cp sample.json db_password.json
## Now edit the db_password.json file. Save it
```

## Import database schema and sample data

Log in to a MySQL account that has sufficient privileges to create new databases and tables. Create a database called `db_project` and then source the `db.sql` file.

```sql
CREATE DATABASE db_project;
SOURCE db.sql;
```

## Running

Front server

```bash
source venvDBProject/bin/activate
cd venvDBProject/DBProject
python3 run.py frontend
```

Backend server (please open a separate terminal window)

```bash
source venvDBProject/bin/activate
cd venvDBProject/DBProject
python3 run.py backend
```

This is a 3-tier web service.

Front server will be available at http://127.0.0.1:5000/

Backend server will be available at http://127.0.0.1:5001/

## Frontend Endpoints

- `/my_ledger`
- `/my_contacts`
- `/my_ledger/new_tx/{uid}`
- `/my_ledger/confirm_tx/{txid}`

Login is required. Sample usernames and passwords are in `sample_users.txt`

By default, only John, Tom and Paul have associated bank accounts. Additional bank accounts (and money) can be created by using backend endpoints.

## Backend Endpoints

A "privileged" tier: login is not required on this service.

- `GET /private_sign_up.html`
- `GET /user/id/{uid}/contacts` (contact list)
- `PUT /user/id/{uid}/contacts` (put another user in the contact list; request body required: `id2={another user's uid}`)
- `DELETE /user/id/{uid}/contacts` (delete a user from the contact list; request body required: `id2={another user's uid}`)
- `PUT /account/{uid}` (creates associated bank account for existing user)
- `GET /account/{uid}/tx` (ledger)
- `POST /account/{from_id}/tx/new/{to_id}` (initiates a pending money transaction; request body: `amount={integer, number of cents to send}`)
- `POST /account/{uid}/tx/new_external` (adds money to or subtracts money from a user's bank account; request body: `amount={integer, number of cents}`)
- `POST /account/{uid}/tx/confirm/{txid}` (confirms transaction; all transactions need confirmation; no request body for this endpoint)

## DB Schema, first iteration:

```
Transaction(id, from_user, to_user, date, amount, remaining_balance, status)
Account(user, balance)
User(id, password, display_handle, full_name)
Contact(user, follows_user)
```

Primary keys:

- Transaction.id
- Account.user
- User.id
- (Contact.user, Contact.follows_user)

Foreign keys:

- Transaction.from_user, Transaction.to_user, Account.user, Contact.user, Contact.follows_user reference User.id

## DB Schema, Second iteration:

```
PendingTransaction(id, from_user, to_user, amount)
ApprovedTransaction(id, from_user, to_user, amount, time, remaining_balance)
PendingExtTransaction(id, user, amount)
ApprovedExtTransaction(id, user, amount, time, remaining_balance)
Account(user, balance)
User(id, password, display_handle, full_name)
Contact(user, follows_user)
```

Primary keys:

- PendingTransaction.id
- ApprovedTransaction.id
- PendingExtTransaction.id
- ApprovedExtTransaction.id
- Account.user
- User.id
- (Contact.user, Contact.follows_user)

Foreign keys:

- PendingTransaction.from_user, PendingTransaction.to_user reference User.id
- ApprovedTransaction.from_user, ApprovedTransaction.to_user reference User.id
- PendingExtTransaction.user, ApprovedExtTransaction.user reference User.id
- Account.user, Contact.user, Contact.follows_user reference User.id

## DB Schema, Third iteration:

```
PendingTransaction(id, from_user, to_user, amount)
ApprovedTransaction(id, from_user, to_user, amount, time, new_balance_f, new_balance_t)
PendingExtTransaction(id, user, amount)
ApprovedExtTransaction(id, user, amount, time, remaining_balance)
Account(user, balance)
User(id, password, display_handle, full_name)
Contact(user, follows_user)
LoginSession(user, cookie)
```

Primary keys:

- PendingTransaction.id
- ApprovedTransaction.id
- PendingExtTransaction.id
- ApprovedExtTransaction.id
- Account.user
- User.id
- (Contact.user, Contact.follows_user)

Foreign keys:

- PendingTransaction.from_user, PendingTransaction.to_user reference User.id
- ApprovedTransaction.from_user, ApprovedTransaction.to_user reference User.id
- PendingExtTransaction.user, ApprovedExtTransaction.user reference User.id
- Account.user, Contact.user, Contact.follows_user, LoginSession.user reference User.id
