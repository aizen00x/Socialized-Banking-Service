import flask
from . import db_layer
import model
import functools
import contextlib
import datetime

app = flask.Flask(__name__)

def catch_bind_errors(original_func):
    @functools.wraps(original_func)
    def new_func(*args, **kwargs):
        try:
            return original_func(*args, **kwargs)
        except model.BindError as e:
            return {'msg': str(e)}, 400
    return new_func

@app.route('/private_sign_up.html', methods=('GET', 'POST'))
@catch_bind_errors
def private_sign_up():
    if flask.request.method == 'GET':
        return flask.render_template('private_sign_up.html')
    reg = model.RegistrationForm.from_post_data(flask.request.form)
    return _create_user(reg)

@app.route('/user/create', methods=('POST',))
@catch_bind_errors
def create_user():
    reg = model.RegistrationForm.from_trusted_data(flask.request.form)
    return _create_user(reg)

def _create_user(reg):
    # Insert into database (safe even if the handle already exists)
    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    INSERT INTO User (password, display_handle, full_name)
    SELECT * FROM (SELECT %s AS p, %s AS d, %s AS f) AS temp
    WHERE NOT EXISTS (SELECT * FROM User WHERE display_handle = %s)
    """
    cursor.execute(
        stmt,
        (reg.password_hash, reg.display_handle, reg.full_name,
         reg.display_handle)
    )
    conn.commit()  # auto-commit is off in Python connector
    rows_affected = cursor.rowcount
    cursor.close()
    conn.close()

    if rows_affected == 0:
        return 'Failed: there is a user under the same handle', 409
    else:
        return 'Account created', 201

def extract_id2():
    try:
        id2 = int(flask.request.form['id2'])
        return id2
    except KeyError:
        raise model.BindError('Key id2 is not found')
    except ValueError:
        raise model.BindError('Invalid id2')

@app.route('/user/id/<int:uid>/contacts', methods=('GET', 'PUT', 'DELETE'))
@catch_bind_errors
def contacts(uid):
    if flask.request.method == 'GET':
        # GET: get all contacts
        return flask.jsonify(get_contacts(uid))

    if flask.request.method == 'PUT':
        # PUT: put User `id2` in User `uid`'s contact; id2 in request body
        return put_into_contact(uid, extract_id2())

    if flask.request.method == 'DELETE':
        # DELETE: delete User `id2` from `uid`'s contact; id2 in request body
        return delete_from_contact(uid, extract_id2())

    return 'Not implemented', 501

def get_contacts(uid):
    result = []
    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    SELECT id, display_handle, full_name FROM User WHERE id IN
    (SELECT follows_user FROM Contact WHERE user = %s)
    """
    cursor.execute(stmt, (uid,))
    for row in cursor:
        user = model.User(id=row[0], display_handle=row[1], full_name=row[2])
        result.append(user.serialize())
    cursor.close()
    conn.close()
    return result

def put_into_contact(uid, id2):
    """Indempotent function to put id2 into uid's contact. The identifiers can
    be invalid"""
    if uid == id2: return 'You cannot follow yourself', 409
    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    INSERT INTO Contact (user, follows_user)
    SELECT * FROM (SELECT %s as user, %s as follows_user) AS t WHERE
    EXISTS (SELECT * FROM User WHERE id = %s) AND
    EXISTS (SELECT * FROM User WHERE id = %s) AND
    NOT EXISTS (SELECT * FROM Contact WHERE user = %s AND follows_user = %s)
    """
    cursor.execute(stmt, (uid, id2, uid, id2, uid, id2))
    conn.commit()
    cursor.close()
    conn.close()
    return '', 204

def delete_from_contact(uid, id2):
    """Indempotent function to delete id2 from uid's contact. The identifiers
    can be invalid"""
    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    DELETE FROM Contact WHERE user = %s AND follows_user = %s
    """
    cursor.execute(stmt, (uid, id2))
    conn.commit()
    cursor.close()
    conn.close()
    return '', 204

# Transactions

@app.route('/account/<int:uid>', methods=('GET', 'PUT'))
def account_endpoint(uid):
    if flask.request.method == 'PUT':
        return create_account_for_transactions(uid)
    return 'Not implemented', 501

def create_account_for_transactions(uid):
    """Safe function to create the user's account in the Account table"""
    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    INSERT INTO Account (user, balance) SELECT * FROM
    (SELECT %s as user, 0 as balance) AS t WHERE
    EXISTS (SELECT * FROM User WHERE id = %s) AND
    NOT EXISTS (SELECT * FROM Account WHERE user = %s)
    """
    cursor.execute(stmt, (uid, uid, uid))
    conn.commit()
    cursor.close()
    conn.close()
    return '', 204

@app.route('/account/<int:uid>/tx')
def list_transactions(uid):
    """List all transactions, internal and external"""
    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    WITH t (type, id, user, other, your_diff, time, remaining_balance) AS (
    --
    SELECT 'PE', id, user, NULL, amount, NULL, NULL
    FROM PendingExtTransaction UNION
    --
    SELECT 'AE', id, user, NULL, amount, time, remaining_balance
    FROM ApprovedExtTransaction UNION
    --
    SELECT 'PT', id, from_user, to_user, -amount, NULL, NULL
    FROM PendingTransaction UNION
    --
    SELECT 'AT', id, from_user, to_user, -amount, time, new_balance_f
    FROM ApprovedTransaction UNION
    --
    SELECT 'AT', id, to_user, from_user, amount, time, new_balance_t
    FROM ApprovedTransaction
    )
    -- --
    SELECT * FROM t WHERE user = %s
    ORDER BY time DESC, type DESC, id DESC
    """
    cursor.execute(stmt, (uid,))
    result = []
    for row in cursor:
        tx = model.PersonalLedgerEntry(
            type=row[0], id=row[1], user=row[2], other=row[3],
            your_diff=row[4], time=row[5], remaining_balance=row[6]
        )
        result.append(tx.serialize())
    return flask.jsonify(result)

def _extract_amount_as_int(allow_negative=False):
    """Extract the amount (number of cents) from HTTP form data"""
    try:
        amount = int(flask.request.form.get('amount'))
    except (TypeError, ValueError) as e:
        raise model.BindError('Invalid amount') from e
    # range check
    if amount == 0:
        raise model.BindError('Amount should not be 0')
    if amount < 0 and not allow_negative:
        raise model.BindError('Amount should be positive')
    return amount

@app.route('/account/<int:from_id>/tx/new/<int:to_id>', methods=('POST',))
@catch_bind_errors
def new_tx(from_id, to_id):
    """Create a pending transaction between two users"""
    amount = _extract_amount_as_int()
    if from_id == to_id:
        raise model.BindError('You cannot send money to yourself')

    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    INSERT INTO PendingTransaction (from_user, to_user, amount) SELECT *
    FROM (SELECT %s AS FU, %s AS TU, %s AS AMT) as t WHERE
    EXISTS (SELECT * FROM User WHERE id = %s) AND
    EXISTS (SELECT * FROM User WHERE id = %s)
    """
    cursor.execute(stmt, (from_id, to_id, amount, from_id, to_id))
    conn.commit()
    rows_affected = cursor.rowcount
    last_row_id = cursor.lastrowid
    cursor.close()
    conn.close()

    # If no rows were added, FAIL
    if rows_affected == 0:
        return 'Invalid user ID', 400
    # Return the transaction ID
    return {'id': 'PT' + str(last_row_id)}

@app.route('/account/<int:uid>/tx/new_external', methods=('POST',))
@catch_bind_errors
def new_external_tx(uid):
    """Create a pending deposit or withdrawal"""
    amount = _extract_amount_as_int(allow_negative=True)
    # Positive: deposit. Negative: withdrawal
    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    INSERT INTO PendingExtTransaction (user, amount) SELECT *
    FROM (SELECT %s as user, %s as amount) as t WHERE
    EXISTS (SELECT * FROM User WHERE id = %s)
    """
    cursor.execute(stmt, (uid, amount, uid))
    conn.commit()
    rows_affected = cursor.rowcount
    last_row_id = cursor.lastrowid
    cursor.close()
    conn.close()
    if rows_affected == 0:
        return 'Invalid user ID', 400
    else:
        return {'id': 'PE' + str(last_row_id)}

class Rollback(Exception): pass

@contextlib.contextmanager
def start_transaction(**kwargs):
    conn = db_layer.connect()
    conn.start_transaction(*kwargs)
    cursor = conn.cursor(prepared=True)
    try:
        yield conn, cursor
    except Rollback as rb:
        conn.rollback()
        raise model.BindError(rb.args[0]) from rb
    finally:
        cursor.close()
        conn.close()

def _extract_type_and_numeric_id(txid):
    # Type
    prefix = txid[:2]
    if prefix not in ('PT', 'PE'):
        raise model.BindError('Invalid TXID prefix')
    # Numeric ID
    suffix = txid[2:]
    if suffix == '' or suffix[0] not in '123456789':
        raise model.BindError('Invalid TXID')
    try:
        numeric_id = int(suffix)
    except ValueError as e:
        raise model.BindError('Invalid TXID') from e
    # Return
    return prefix, numeric_id

@app.route('/account/<int:uid>/tx/confirm/<string:_txid>', methods=('POST',))
@catch_bind_errors
def confirm_tx(uid, _txid):
    """Confirm the transaction"""
    tx_type, numeric_id = _extract_type_and_numeric_id(_txid)
    with start_transaction(isolation_level='SERIALIZABLE') as (conn, cursor):
        if tx_type == 'PT':
            confirm_regular_tx(cursor, uid, numeric_id)
            conn.commit()
            approved_id = 'AT' + str(cursor.lastrowid)
        else:
            confirm_external_tx(cursor, uid, numeric_id)
            conn.commit()
            approved_id = 'AE' + str(cursor.lastrowid)
    # END WITH
    return {'id': approved_id}

def change_account_balance(cursor, uid, difference):
    # Check if the account exists and get the current balance
    cursor.execute("""
    SELECT balance FROM Account WHERE user = %s
    """, (uid,))
    ## 10.5.8 MySQLCursor.fetchone() Method
    ## "You must fetch all rows for the current query before executing new
    ## statements using the same connection."
    row = cursor.fetchall()
    if not row:
        raise Rollback('This user does not have an account')
    current_balance = row[0][0]

    # Update the account with a new balance
    new_balance = current_balance + difference
    if difference < 0 and new_balance < 0:
        raise Rollback('Insufficient funds')
    cursor.execute("""
    UPDATE Account SET balance = %s WHERE user = %s
    """, (new_balance, uid))

    # Return remaining balance (the new balance)
    return new_balance

def confirm_external_tx(cursor, uid, numeric_id):
    # Check if the pending transaction exists and get the difference
    cursor.execute("""
    SELECT amount From PendingExtTransaction WHERE
    user = %s AND id = %s
    """, (uid, numeric_id))
    tx_row = cursor.fetchall()
    if not tx_row:
        raise Rollback('Transaction not found')
    difference = tx_row[0][0]

    # Update user account
    remaining_balance = change_account_balance(cursor, uid, difference)

    # Move transaction from pending to appproved
    cursor.execute("""
    DELETE FROM PendingExtTransaction WHERE
    user = %s AND id = %s
    """, (uid, numeric_id))
    #
    cursor.execute("""
    INSERT INTO ApprovedExtTransaction
    (user, amount, time, remaining_balance) VALUES
    (%s,   %s,     %s,   %s)
    """, (uid, difference, datetime.datetime.now(), remaining_balance))

def confirm_regular_tx(cursor, from_uid, numeric_id):
    # Get the amount and the to_uid
    cursor.execute("""
    SELECT to_user, amount FROM PendingTransaction WHERE
    from_user = %s AND id = %s
    """, (from_uid, numeric_id))
    tx_row = cursor.fetchall()
    if not tx_row:
        raise Rollback('Transaction not found')
    to_uid = tx_row[0][0]
    amount = tx_row[0][1]

    # Update user account (from_uid)
    new_balance_f = change_account_balance(cursor, from_uid, -amount)
    # Update user account (to_uid)
    new_balance_t = change_account_balance(cursor, to_uid, amount)

    # Move transaction from pending to approved
    cursor.execute("""
    DELETE FROM PendingTransaction WHERE
    from_user = %s AND id = %s
    """, (from_uid, numeric_id))
    #
    now = datetime.datetime.now()
    cursor.execute("""
    INSERT INTO ApprovedTransaction
    (from_user, to_user, amount, time, new_balance_f, new_balance_t) VALUES
    (%s,        %s,      %s,     %s,   %s,            %s)
    """, (from_uid, to_uid, amount, now, new_balance_f, new_balance_t))

if __name__ == '__main__':
    app.run()
