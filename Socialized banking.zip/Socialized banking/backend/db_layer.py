import mysql.connector

db_config = None

def init(config):
    global db_config
    db_config = config

def connect():
    conn = mysql.connector.connect(**db_config)
    return conn
