-- sudo mysql -u root -p

-- Database name
USE db_project;

CREATE TABLE User(
id INT NOT NULL AUTO_INCREMENT,
password VARCHAR(255) NOT NULL,
display_handle VARCHAR(80) NOT NULL UNIQUE,
full_name VARCHAR(255),
PRIMARY KEY (id)
);

CREATE TABLE Contact(
user INT NOT NULL,
follows_user INT NOT NULL,
PRIMARY KEY (user, follows_user),
FOREIGN KEY (user) REFERENCES User(id) ON DELETE CASCADE,
FOREIGN KEY (follows_user) REFERENCES User(id) ON DELETE CASCADE
);

CREATE TABLE Account(
user INT NOT NULL,
balance INT NOT NULL,  -- number of cents
PRIMARY KEY (user),
FOREIGN KEY (user) REFERENCES User(id) ON DELETE CASCADE
);

CREATE TABLE PendingTransaction(
id INT NOT NULL AUTO_INCREMENT,
from_user INT NOT NULL,
to_user INT NOT NULL,
amount INT NOT NULL,  -- number of cents
PRIMARY KEY (id),
FOREIGN KEY (from_user) REFERENCES User(id) ON DELETE CASCADE,
FOREIGN KEY (to_user) REFERENCES User(id) ON DELETE CASCADE
);

CREATE TABLE ApprovedTransaction(
id INT NOT NULL AUTO_INCREMENT,
from_user INT,
to_user INT,
amount INT NOT NULL,  -- number of cents
time DATETIME NOT NULL,
new_balance_f INT NOT NULL,  -- number of cents
new_balance_t INT NOT NULL,  -- number of cents
PRIMARY KEY (id),
FOREIGN KEY (from_user) REFERENCES User(id) ON DELETE SET NULL,
FOREIGN KEY (to_user) REFERENCES User(id) ON DELETE SET NULL
);

CREATE TABLE PendingExtTransaction(
id INT NOT NULL AUTO_INCREMENT,
user INT NOT NULL,
amount INT NOT NULL,  -- number of cents
PRIMARY KEY (id),
FOREIGN KEY (user) REFERENCES User(id) ON DELETE CASCADE
);

CREATE TABLE ApprovedExtTransaction(
id INT NOT NULL AUTO_INCREMENT,
user INT,
amount INT NOT NULL,  -- number of cents
time DATETIME NOT NULL,
remaining_balance INT NOT NULL,  -- number of cents
PRIMARY KEY (id),
FOREIGN KEY (user) REFERENCES User(id) ON DELETE SET NULL
);

CREATE TABLE LoginSession(
user INT NOT NULL,
cookie VARCHAR(255) NOT NULL UNIQUE,
FOREIGN KEY (user) REFERENCES User(id) ON DELETE CASCADE
);

-- Sample data

SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;
BEGIN;

INSERT INTO `User` VALUES
(1,'$argon2id$v=19$m=102400,t=2,p=8$3+o9x7umQ8w0LqwFqyN2RQ$MEvfU0YEvNpNgB9weuYpUg','john','John'),
(2,'$argon2id$v=19$m=102400,t=2,p=8$4oKuALUseZ3Vl0g+xdibsg$Q4ldG2U9s7ciDeM/08q0AA','tom','Tom'),
(3,'$argon2id$v=19$m=102400,t=2,p=8$RVk5IhrHoROZtM6vnRQ0kA$h2cSLUtwfMUwJC2Wi8YanQ','richard','Richard'),
(4,'$argon2id$v=19$m=102400,t=2,p=8$oq4CJJ+/eRxUh8tsexQvLA$BfoJoxDflYwKPrnHASfazQ','george','George'),
(5,'$argon2id$v=19$m=102400,t=2,p=8$B4FLnhCCSpe7ui78qaxJfQ$JxPxgRN1wi2nmGCUL5XuZw','paul','Paul'),
(6,'$argon2id$v=19$m=102400,t=2,p=8$wYvSj5wshUTlBRVDz5mS0A$unt4L6aF2EYuu8MGsZswXQ','mike','Mike'),
(7,'$argon2id$v=19$m=102400,t=2,p=8$Rr3UBXzyvkcMMLriuLty4w$Kf2BkroSMgebTv6/ofsDVg','roy','Roy'),
(8,'$argon2id$v=19$m=102400,t=2,p=8$qdHLCDAe4+uRwCySqZ2/vA$IgbkVwb1hcNzhKH/llu23Q','bob','Bob'),
(9,'$argon2id$v=19$m=102400,t=2,p=8$jBAQF1ehpd/TdcOVoesSag$g8aRvkA9DgUltVH1pYNnaw','ben','Ben'),
(10,'$argon2id$v=19$m=102400,t=2,p=8$whepx9GJF/lf9feVlq5wNw$Nd77RPpBWnAFDcERSt/ZVg','sean','Sean');

INSERT INTO `Contact` VALUES
(1,3),(1,4),(1,5),
(2,4),(2,6),(2,7),(2,8),(2,9),
(4,1),(4,2),(4,3),(4,5),(4,7),(4,8),
(10,1);

INSERT INTO `Account` VALUES
(1,7000), (2,10050), (5, 20100);

COMMIT;
