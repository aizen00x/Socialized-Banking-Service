#!/usr/bin/env python3
import backend.db_layer as db_layer
import os
import json
import sys

def run_backend():
    from backend.main import app
    app.run(port=5001)

def run_frontend():
    from frontend.main import app
    app.run(port=5000)

def main(argv):
    if len(argv) != 2 or argv[1] not in ('frontend', 'backend'):
        print('Usage: ./run.py [frontend|backend]', file=sys.stderr)
        sys.exit(1)

    # Load database config
    dirname = os.path.dirname(__file__) or '.'
    config_path = dirname + '/db_password.json'
    with open(config_path, 'r', encoding='utf-8') as fd:
        db_layer.init(json.load(fd))

    if argv[1] == 'frontend':
        run_frontend()
    else:
        run_backend()

if __name__ == '__main__':
    main(sys.argv)
