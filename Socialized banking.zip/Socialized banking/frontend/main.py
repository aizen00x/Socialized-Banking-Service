import os
import base64
import flask
import functools
import backend.db_layer as db_layer
import model
import requests

service_url = 'http://127.0.0.1:5001'

app = flask.Flask(__name__)

def check_cookie(original):
    @functools.wraps(original)
    def wrapped(*args, **kwargs):
        token = flask.request.cookies.get('token') or 'INVALID'

        conn = db_layer.connect()
        cursor = conn.cursor(prepared=True)
        stmt = """
        SELECT id, display_handle, full_name FROM User WHERE
        id IN (SELECT user FROM LoginSession WHERE cookie = %s)
        """
        cursor.execute(stmt, (token,))
        row = cursor.fetchall()
        cursor.close()
        conn.close()

        if not row:
            res = flask.make_response('', 303)
            res.set_cookie('token', 'INVALID')
            res.headers['Location'] = '/login'
            return res
        elif len(row) != 1:
            raise RuntimeError('Multiple users sharing the same cookie')
        else:
            # construct session object (it's just a user object)
            session = model.User(
                id=row[0][0],
                display_handle=row[0][1],
                full_name=row[0][2]
            )
            return original(*args, **kwargs, session=session)

    return wrapped

@app.route('/login', methods=('GET', 'POST'))
def login_page():
    """Login page"""
    if flask.request.method == 'GET':
        return flask.render_template('login.html')

    # Parse post data
    form_model = model.LoginForm.from_post_data(flask.request.form)

    # Retrieve password hash
    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    SELECT password, id FROM User WHERE
    display_handle = %s
    """
    cursor.execute(stmt, (form_model.display_handle,))
    row = cursor.fetchall()
    cursor.close()
    conn.close()

    if not row:
        return flask.render_template('login.html', error='No such user')
    password_hash = row[0][0]
    uid = row[0][1]

    # Compare password
    if not form_model.compare_password(password_hash):
        return flask.render_template('login.html', error='Wrong pass')

    # Establish session
    with open('/dev/urandom', 'rb') as fd:
        random_data = fd.read(8)
    cookie = base64.b64encode(random_data, b'-_').decode('ascii')

    conn = db_layer.connect()
    cursor = conn.cursor(prepared=True)
    stmt = """
    INSERT INTO LoginSession (user, cookie) VALUES (%s, %s)
    """
    cursor.execute(stmt, (uid, cookie))
    conn.commit()
    cursor.close()
    conn.close()

    # Set cookie
    res = flask.make_response('', 303)
    res.set_cookie('token', cookie)
    res.headers['Location'] = '/'
    return res

def tunnel_response(resp):
    flask_response = flask.make_response(resp.text, resp.status_code)
    content_type = resp.headers.get('Content-Type')
    if content_type:
        flask_response.headers['Content-Type'] = content_type
    return flask_response

@app.route('/')
@check_cookie
def main_page(*args, session):
    """Main page"""
    return flask.render_template('index.html')

@app.route('/my_contacts')
@check_cookie
def my_contacts(*args, session):
    """My contacts"""
    html_data = []
    endpoint = service_url + '/user/id/' + str(session.id) + '/contacts'
    resp = requests.get(endpoint)
    if not resp.ok:
        return tunnel_response(resp)

    parsed_object = resp.json()
    for contact_map in parsed_object:
        contact = model.User(
            id=contact_map['id'],
            display_handle=contact_map['display_handle'],
            full_name=contact_map['full_name']
        )
        send_money = flask.url_for('new_tx', uid2=contact.id)
        delete_me = flask.url_for('delete_contact', uid2=contact.id)
        html_data.append("<div>")
        html_data.append("""
        <span>{}</span> <span>(@{})</span>
        <a href="{}">Send money</a>
        """.format(
            flask.escape(contact.full_name),
            flask.escape(contact.display_handle),
            flask.escape(send_money)
        ))
        html_data.append("""
        <form method="POST" action="{}">
        <input type="submit" value="Delete from contact">
        </form>
        """.format(flask.escape(delete_me)))
        html_data.append('</div>')

    return flask.render_template(
        'my_contacts.html',
        html_data=''.join(html_data)
    )

@app.route('/my_contacts/delete/<int:uid2>', methods=('POST',))
@check_cookie
def delete_contact(uid2, *args, session):
    """Delete person from my contacts"""
    return user_contact_action(requests.delete, uid2, session)

@app.route('/my_contacts/put', methods=('POST',))
@check_cookie
def put_in_contact(*args, session):
    """Put person in my contacts"""
    try:
        uid2 = int(flask.request.form.get('id') or '')
    except ValueError:
        return 'Invalid UID', 400
    return user_contact_action(requests.put, uid2, session)

def user_contact_action(method, id2, session):
    endpoint = service_url + '/user/id/' + str(session.id) + '/contacts'
    resp = method(endpoint, data={'id2': id2})
    if resp.ok:
        return flask.redirect(flask.url_for('my_contacts'))
    else:
        return tunnel_response(resp)

def format_cents(cents):
    if cents is None:
        return ''
    integer_part = cents // 100
    decimal_part = cents % 100
    padding = '0' if decimal_part < 10 else ''
    return '${}.{}{}'.format(integer_part, padding, decimal_part)

@app.route('/my_ledger')
@check_cookie
def my_ledger(*args, session):
    """Displays transaction history"""
    html_data = []
    endpoint = service_url + '/account/' + str(session.id) + '/tx'
    resp = requests.get(endpoint)
    if not resp.ok:
        return tunnel_response(resp)

    parsed_array = resp.json()
    for element in parsed_array:
        html_data.append("""
        <tr>
        <td>{}</td>
        <td>{}</td>
        <td>{}</td>
        <td>{}</td>
        <td>{}</td>
        </tr>
        """.format(
            element['id'],
            element['other'] or '',
            element['time'] or '',
            format_cents(element['your_diff']),
            format_cents(element['remaining_balance'])
        ))

    return flask.render_template(
        'my_ledger.html',
        ledger_table=''.join(html_data)
    )

@app.route('/my_ledger/new_external_tx')
@check_cookie
def new_external_tx(*args, session):
    """New external transaction"""
    return ''

@app.route('/my_ledger/new_tx/<int:uid2>', methods=('GET', 'POST'))
@check_cookie
def new_tx(uid2, *args, session):
    """New regular transaction"""
    if flask.request.method == 'GET':
        return flask.render_template('new_tx.html', other=uid2)

    post_data = flask.request.form.get('amount', '')
    endpoint = '{}/account/{}/tx/new/{}'.format(
        service_url, session.id, uid2
    )
    resp = requests.post(endpoint, data={'amount': post_data})
    if not resp.ok:
        return tunnel_response(resp)
    else:
        txid = resp.json()['id']
        return flask.redirect(flask.url_for('confirm_tx', txid=txid))

@app.route('/my_ledger/confirm_tx/<txid>', methods=('GET', 'POST'))
@check_cookie
def confirm_tx(txid, *args, session):
    """Confirm transaction"""
    if flask.request.method == 'GET':
        return flask.render_template('confirm_tx.html')

    endpoint = '{}/account/{}/tx/confirm/{}'.format(
        service_url, session.id, txid
    )
    resp = requests.post(endpoint)
    if not resp.ok:
        return tunnel_response(resp)
    else:
        return flask.redirect(flask.url_for('my_ledger'))
